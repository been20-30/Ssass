import AdmZip from 'adm-zip';
import path from 'path';
import fs from 'fs';

async function packageZip() {
  const zip = new AdmZip();
  const sourceDir = path.resolve('android_project');
  
  if (!fs.existsSync(sourceDir)) {
    throw new Error('android_project directory does not exist');
  }

  // Add local folder
  zip.addLocalFolder(sourceDir, 'MyAndroidApp');

  const outputDir = path.resolve('public');
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const outputPath = path.join(outputDir, 'MyAndroidApp-Studio-Project.zip');
  zip.writeZip(outputPath);
  console.log('Zip file created successfully at:', outputPath, 'Size:', fs.statSync(outputPath).size);
}

packageZip().catch(console.error);
