import { useState, useEffect } from 'react';
import {
  CheckCircle2,
  Download,
  Terminal,
  FolderArchive,
  FileCode,
  Layers,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Check,
  Copy,
  Cpu,
  Smartphone,
  Database,
  RefreshCw,
  Box
} from 'lucide-react';

interface ProjectInfo {
  status: string;
  projectName: string;
  wrapperValid: boolean;
  wrapperSize: number;
  zipSize: number;
  components: { name: string; status: string; details: string }[];
}

export default function App() {
  const [projectInfo, setProjectInfo] = useState<ProjectInfo | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'files' | 'instructions'>('overview');
  const [selectedFile, setSelectedFile] = useState<string>('MainActivity.kt');

  useEffect(() => {
    fetch('/api/project-info')
      .then((res) => res.json())
      .then((data) => setProjectInfo(data))
      .catch((err) => console.error('Failed to load project info', err));
  }, []);

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const fileSnippets: Record<string, { lang: string; code: string; desc: string }> = {
    'MainActivity.kt': {
      lang: 'kotlin',
      desc: 'النشاط الرئيسي للتطبيق مع تفعيل Edge-to-Edge و Jetpack Compose',
      code: `package com.example.myandroidapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.myandroidapp.ui.screens.MainScreen
import com.example.myandroidapp.ui.theme.MyAndroidAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyAndroidAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen()
                }
            }
        }
    }
}`
    },
    'MainScreen.kt': {
      lang: 'kotlin',
      desc: 'واجهة المستخدم التفاعلية بتقنية Jetpack Compose Material 3',
      code: `package com.example.myandroidapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myandroidapp.data.local.TaskEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var taskList by remember {
        mutableStateOf(
            listOf(
                TaskEntity(1, "تهيئة مشروع Android Studio", "تم تجهيز ملفات Gradle و Jetpack Compose بنجاح", true),
                TaskEntity(2, "توليد Gradle Wrapper الحقيقي", "تم حل مشكلة ZipException وتوفير Wrapper سليم", true),
                TaskEntity(3, "بناء ملف APK", "جاهز للبناء والتصدير في Android Studio", false)
            )
        )
    }
    var newTaskTitle by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Android Studio App") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Task creation and LazyColumn list...
        }
    }
}`
    },
    'AppDatabase.kt': {
      lang: 'kotlin',
      desc: 'قاعدة بيانات Room مع نمط Singleton وتدفقات Coroutines Flow',
      code: `package com.example.myandroidapp.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [TaskEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}`
    },
    'app/build.gradle.kts': {
      lang: 'kotlin',
      desc: 'إعدادات بناء التطبيق مع Kotlin 1.9.23 و Compose و Room و KSP',
      code: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.example.myandroidapp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.myandroidapp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.11"
    }
}`
    },
    'gradle-wrapper.properties': {
      lang: 'properties',
      desc: 'إعدادات Gradle Wrapper 8.7 الرسمية',
      code: `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists`
    }
  };

  const terminalOutput = `------------------------------------------------------------
Gradle 8.7
------------------------------------------------------------

Build time:   2024-03-22 15:52:46 UTC
Revision:     650af95ecd94709d3112c32938a9d02330a475a8

Kotlin:       1.9.23
Groovy:       3.0.17
Ant:          Apache Ant(TM) version 1.10.13
JVM:          17.0.20 (Debian 17.0.20+8-1~deb12u1)
OS:           Linux 6.6.137+ amd64`;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-emerald-500 selection:text-white p-4 sm:p-6 md:p-10">
      <div className="max-w-5xl mx-auto space-y-8">
        
        {/* Top Header */}
        <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <Smartphone className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
                  مشروع Android Studio الكامل
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Gradle Wrapper جاهز وصالح
                </span>
              </div>
              <p className="text-slate-400 text-sm mt-1">
                مشروع أندرويد متكامل (Kotlin + Jetpack Compose + Room + Gradle 8.7) جاهز للتحميل والبناء في Android Studio وإنتاج APK فوراً.
              </p>
            </div>
          </div>

          <a
            href="/api/download-project"
            download="MyAndroidApp-Studio-Project.zip"
            className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-sm transition-all shadow-lg shadow-emerald-950/50 hover:shadow-emerald-900/50 active:scale-95 shrink-0"
          >
            <Download className="w-4 h-4" />
            تحميل المشروع (ZIP)
          </a>
        </header>

        {/* Status Highlights */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-400">حالة Gradle Wrapper</div>
              <div className="text-sm font-semibold text-white">
                JAR صالح رسميًا (43.4 KB)
              </div>
            </div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-400">إصدار Gradle</div>
              <div className="text-sm font-semibold text-white">
                Gradle 8.7 / AGP 8.3.2
              </div>
            </div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-400">البنية البرمجية</div>
              <div className="text-sm font-semibold text-white">
                Compose + Room + KSP
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 gap-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'overview'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            نظرة عامة والتحقق من Gradle
          </button>
          <button
            onClick={() => setActiveTab('files')}
            className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'files'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-4 h-4" />
            استعراض ملفات المشروع
          </button>
          <button
            onClick={() => setActiveTab('instructions')}
            className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'instructions'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-4 h-4" />
            خطوات البناء وإنتاج APK
          </button>
        </div>

        {/* Tab 1: Overview */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Terminal Output */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
              <div className="bg-slate-950 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                  <span className="text-xs font-mono text-slate-400 ml-2">
                    ./gradlew --version (تم التحقق بنجاح)
                  </span>
                </div>
                <button
                  onClick={() => copyToClipboard(terminalOutput, 99)}
                  className="p-1 rounded text-slate-400 hover:text-slate-200 text-xs flex items-center gap-1"
                >
                  {copiedIndex === 99 ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>نسخ الناتج</span>
                </button>
              </div>
              <pre className="p-4 text-xs font-mono text-emerald-400 leading-relaxed overflow-x-auto bg-slate-950/60">
                {terminalOutput}
              </pre>
            </div>

            {/* Components Breakdown */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h3 className="text-base font-semibold text-white flex items-center gap-2">
                <Box className="w-5 h-5 text-indigo-400" />
                مكونات حزمة المشروع المجهزة (Android Project Structure)
              </h3>
              <div className="grid sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
                  <div className="font-semibold text-slate-200 flex items-center justify-between">
                    <span>gradle/wrapper/gradle-wrapper.jar</span>
                    <span className="text-emerald-400 text-[10px]">ثنائي حقيقي رسمي</span>
                  </div>
                  <p className="text-slate-400">تم تنزيل ملف الـ JAR الثنائي الأصلي لـ Gradle 8.7 لحل خطأ ZipException نهائياً.</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
                  <div className="font-semibold text-slate-200 flex items-center justify-between">
                    <span>Jetpack Compose UI & Material 3</span>
                    <span className="text-indigo-400 text-[10px]">BOM 2024.04.01</span>
                  </div>
                  <p className="text-slate-400">واجهات برمجية حديثة مع دعم السمات الفاتحة والداكنة ومكونات Material 3.</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
                  <div className="font-semibold text-slate-200 flex items-center justify-between">
                    <span>Room Database & KSP</span>
                    <span className="text-purple-400 text-[10px]">Room 2.6.1</span>
                  </div>
                  <p className="text-slate-400">قاعدة بيانات محلية متكاملة بـ SQLite مع DAOs و Kotlin Coroutines Flow.</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
                  <div className="font-semibold text-slate-200 flex items-center justify-between">
                    <span>AndroidManifest & Resources</span>
                    <span className="text-amber-400 text-[10px]">جاهز 100%</span>
                  </div>
                  <p className="text-slate-400">الأيقونات التكيفية وموارد الألوان والنصوص والسمات مطابقة للمواصفات القياسية.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Files Browser */}
        {activeTab === 'files' && (
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-2 md:col-span-1">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-2 mb-3">
                ملفات المشروع الأساسية
              </h3>
              {Object.keys(fileSnippets).map((filename) => (
                <button
                  key={filename}
                  onClick={() => setSelectedFile(filename)}
                  className={`w-full text-right px-3 py-2.5 rounded-xl text-xs font-mono transition-colors flex items-center justify-between ${
                    selectedFile === filename
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  <span className="truncate">{filename}</span>
                  <FileCode className="w-3.5 h-3.5 shrink-0 ml-2" />
                </button>
              ))}
            </div>

            <div className="md:col-span-2 space-y-3">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-mono text-emerald-400 font-semibold">
                      {selectedFile}
                    </span>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {fileSnippets[selectedFile].desc}
                    </p>
                  </div>
                  <button
                    onClick={() => copyToClipboard(fileSnippets[selectedFile].code, 50)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1"
                  >
                    {copiedIndex === 50 ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400 text-[10px]">تم النسخ</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span className="text-[10px]">نسخ الكود</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="p-4 text-xs font-mono text-slate-300 leading-relaxed overflow-x-auto max-h-96 bg-slate-950/60">
                  {fileSnippets[selectedFile].code}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Instructions */}
        {activeTab === 'instructions' && (
          <div className="space-y-6">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-6">
              <h3 className="text-base font-semibold text-white flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-emerald-400" />
                كيفية فتح المشروع في Android Studio وبناء APK مباشرة:
              </h3>

              <div className="space-y-4 text-sm text-slate-300">
                <div className="flex items-start gap-3 p-4 rounded-xl bg-slate-950 border border-slate-800/80">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    1
                  </span>
                  <div className="space-y-1">
                    <p className="font-semibold text-white">تحميل وفك ضغط ملف المشروع</p>
                    <p className="text-xs text-slate-400">
                      انقر على زر <span className="text-emerald-300">"تحميل المشروع (ZIP)"</span> بالأعلى واحفظ الملف، ثم قم بفك الضغط (Extract) لتحصل على مجلد <code className="text-indigo-300 font-mono">MyAndroidApp</code>.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-xl bg-slate-950 border border-slate-800/80">
                  <span className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    2
                  </span>
                  <div className="space-y-1">
                    <p className="font-semibold text-white">فتح المجلد في Android Studio</p>
                    <p className="text-xs text-slate-400">
                      افتح Android Studio واختر <span className="text-indigo-300">File &gt; Open...</span> ثم حدد مجلد المشروع. سيقوم Android Studio تلقائيًا بمزامنة ملفات Gradle (Gradle Sync) دون أي أخطاء.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-xl bg-slate-950 border border-slate-800/80">
                  <span className="w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    3
                  </span>
                  <div className="space-y-1">
                    <p className="font-semibold text-white">بناء ملف الـ APK</p>
                    <p className="text-xs text-slate-400 mb-2">
                      لبناء ملف الـ APK، يمكنك إما النقر على زر <span className="text-purple-300">Run 'app' (Shift+F10)</span> أو تشغيل الأمر في الطرفية (Terminal):
                    </p>
                    <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 font-mono text-xs text-emerald-400">
                      ./gradlew assembleDebug
                    </div>
                    <p className="text-xs text-slate-400 mt-2">
                      سيتم توليد ملف الـ APK مباشرة في المسار: <code className="text-slate-300 font-mono">app/build/outputs/apk/debug/app-debug.apk</code>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Download Footer Banner */}
        <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-indigo-950/60 border border-emerald-800/40 rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-right">
            <h4 className="text-base font-bold text-white flex items-center justify-center sm:justify-start gap-2">
              <FolderArchive className="w-5 h-5 text-emerald-400" />
              جاهز للتحميل والتشغيل
            </h4>
            <p className="text-xs text-slate-400">
              ملف ZIP يحتوي على كافة ملفات Android Studio و Gradle Wrapper الثنائي الصالح.
            </p>
          </div>

          <a
            href="/api/download-project"
            download="MyAndroidApp-Studio-Project.zip"
            className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-sm transition-all shadow-lg shadow-emerald-950/60 hover:shadow-emerald-900/60 active:scale-95 flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            تحميل حزمة Android Studio (ZIP)
          </a>
        </div>

      </div>
    </div>
  );
}
