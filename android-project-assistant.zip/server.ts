import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route to download the Android project ZIP
  app.get('/api/download-project', (req, res) => {
    const zipPath = path.resolve('public/MyAndroidApp-Studio-Project.zip');
    if (fs.existsSync(zipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename=MyAndroidApp-Studio-Project.zip');
      const fileStream = fs.createReadStream(zipPath);
      fileStream.pipe(res);
    } else {
      res.status(404).json({ error: 'Zip file not found' });
    }
  });

  // API Route to get project details and files
  app.get('/api/project-info', (req, res) => {
    const zipPath = path.resolve('public/MyAndroidApp-Studio-Project.zip');
    const wrapperJarPath = path.resolve('android_project/gradle/wrapper/gradle-wrapper.jar');
    
    let wrapperSize = 0;
    if (fs.existsSync(wrapperJarPath)) {
      wrapperSize = fs.statSync(wrapperJarPath).size;
    }

    let zipSize = 0;
    if (fs.existsSync(zipPath)) {
      zipSize = fs.statSync(zipPath).size;
    }

    res.json({
      status: 'ready',
      projectName: 'MyAndroidApp',
      wrapperValid: wrapperSize > 40000,
      wrapperSize,
      zipSize,
      components: [
        { name: 'Gradle Wrapper 8.7 (Official Binary)', status: 'OK', details: `${wrapperSize} bytes` },
        { name: 'Android Gradle Plugin', status: 'OK', details: 'AGP 8.3.2' },
        { name: 'Kotlin & Jetpack Compose', status: 'OK', details: 'Kotlin 1.9.23 / Compose BOM 2024.04.01' },
        { name: 'Room Database & Coroutines', status: 'OK', details: 'Room 2.6.1 + KSP' },
        { name: 'Material 3 UI Theme', status: 'OK', details: 'Full Material 3 color & typography setup' }
      ]
    });
  });

  // Vite middleware for development / static serving in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
